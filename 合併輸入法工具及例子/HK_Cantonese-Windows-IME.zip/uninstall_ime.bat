@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1

net session >nul 2>&1
if errorlevel 1 goto :need_admin

set "NAME=HK_and_IEd_Cantonese"
set "DST64=%ProgramFiles%\%NAME%"

if not exist "%DST64%\%NAME%.dll" goto :unreg_x86
echo Unregistering 64-bit IME (%NAME%)...
regsvr32 /u /s "%DST64%\%NAME%.dll"
del /F /Q "%DST64%\HK_and_IEd_Cantonese.txt" >nul 2>&1
del /F /Q "%DST64%\%NAME%.dll" >nul 2>&1
rmdir "%DST64%" >nul 2>&1

:unreg_x86
if "%ProgramFiles(x86)%"=="" goto :done
set "DST86=%ProgramFiles(x86)%\%NAME%"
if not exist "%DST86%\%NAME%.dll" goto :done
echo Unregistering 32-bit IME (%NAME%)...
"%SystemRoot%\SysWOW64\regsvr32.exe" /u /s "%DST86%\%NAME%.dll"
del /F /Q "%DST86%\HK_and_IEd_Cantonese.txt" >nul 2>&1
del /F /Q "%DST86%\%NAME%.dll" >nul 2>&1
rmdir "%DST86%" >nul 2>&1
goto :done

:need_admin
echo [ERROR] Please right-click this .bat file and select "Run as administrator"!
pause
exit /b 1

:done
echo.
echo ============================================================
echo Uninstall finished!
echo If any DLL file remained locked in Program Files, sign out
echo or reboot Windows and delete the folder manually.
echo ============================================================
pause
