@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1

net session >nul 2>&1
if errorlevel 1 goto :need_admin

set "BASE=%~dp0"
set "NAME=HK_and_IEd_Cantonese"
set "DST64=%ProgramFiles%\%NAME%"

echo [1/3] Checking Windows Chinese language profile...
reg query "HKCU\Control Panel\International\User Profile" /v Languages 2>nul | findstr /I "zh-" >nul
if not errorlevel 1 goto :install_x64
echo [NOTE] No Chinese language detected in current user profile.
echo        If Win+Space does not show the IME after install, please add:
echo        香港繁體中文 (zh-HK)
echo.

:install_x64
if not exist "%BASE%x64\%NAME%.dll" goto :no_dll
echo [2/3] Installing %NAME% (64-bit) to "%DST64%" ...
if not exist "%DST64%" mkdir "%DST64%"
copy /Y "%BASE%x64\%NAME%.dll" "%DST64%\" >nul
copy /Y "%BASE%x64\HK_and_IEd_Cantonese.txt" "%DST64%\" >nul
icacls "%DST64%" /grant *S-1-15-2-1:(OI)(CI)RX >nul 2>&1
regsvr32 /s "%DST64%\%NAME%.dll"
if errorlevel 1 (
    echo [WARN] regsvr32 /s returned non-zero code; retrying interactively...
    regsvr32 "%DST64%\%NAME%.dll"
)

:install_x86
if "%ProgramFiles(x86)%"=="" goto :done
if not exist "%BASE%x86\%NAME%.dll" goto :done
set "DST86=%ProgramFiles(x86)%\%NAME%"
echo [3/3] Installing %NAME% (32-bit support) to "%DST86%" ...
if not exist "%DST86%" mkdir "%DST86%"
copy /Y "%BASE%x86\%NAME%.dll" "%DST86%\" >nul
copy /Y "%BASE%x86\HK_and_IEd_Cantonese.txt" "%DST86%\" >nul
icacls "%DST86%" /grant *S-1-15-2-1:(OI)(CI)RX >nul 2>&1
"%SystemRoot%\SysWOW64\regsvr32.exe" /s "%DST86%\%NAME%.dll"
goto :done

:need_admin
echo [ERROR] Please right-click this .bat file and select "Run as administrator"!
pause
exit /b 1

:no_dll
echo [ERROR] Cannot find x64\%NAME%.dll. Please extract the entire ZIP folder first.
pause
exit /b 1

:done
echo.
echo ============================================================
echo Installation finished!
echo IME Name : 港式及教院式拼音 (%NAME%)
echo Locales  : 香港繁體中文 (zh-HK)
echo Folder   : %DST64%
echo Space    : 空白鍵翻頁（數字鍵 1–9/0 選字；候選需超過 1 頁、>10 個才會翻頁）
echo.
echo 1. Press Win + Space to switch to "港式及教院式拼音"
echo    (Press Shift to toggle Chinese / English mode)
echo 2. If it does not appear immediately, sign out and sign in
echo    again, or run ctfmon.exe.
echo ============================================================
pause
